public class metodoMain {
    public static void main(String[] args) {
        Pessoa p1 = new Pessoa();
        Funcionario f1 = new Funcionario();
    }
    
}
