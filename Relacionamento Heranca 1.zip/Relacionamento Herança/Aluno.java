public class Aluno extends Pessoa {
    private String matricula;
    
}
