public class Empregado extends Pessoa {
    protected int codigoSetor;
    protected float salarioBase;
    protected float Imposto;

    public Empregado(String nome, String endereco, String telefone){
        

    }
    
}
