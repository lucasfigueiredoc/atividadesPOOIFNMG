public class Fornecedor extends Pessoa {
    private float credito;
    private float divida;

    public Fornecedor(String nome, String endereco, String telefone, float credito, float divida){
        super(nome,endereco,telefone);
        this.credito = credito;
        this.divida = divida;
    }

    public float obterSaldo(){
        float retorno = this.divida - this.credito;

        return retorno;
    }


    public float getCredito() {
        return this.credito;
    }

    public void setCredito(float credito) {
        this.credito = credito;
    }

    public float getDivida() {
        return this.divida;
    }

    public void setDivida(float divida) {
        this.divida = divida;
    }

}
